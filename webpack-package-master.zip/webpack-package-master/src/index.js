// @ts-check

import init from './init';

init();
